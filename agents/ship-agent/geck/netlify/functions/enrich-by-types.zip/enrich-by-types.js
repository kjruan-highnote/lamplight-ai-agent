"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/enrich-by-types.ts
var enrich_by_types_exports = {};
__export(enrich_by_types_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(enrich_by_types_exports);
var TYPE_INTROSPECTION_QUERY = `
  query GetTypeDetails($typeName: String!) {
    __type(name: $typeName) {
      name
      kind
      description
      inputFields {
        name
        description
        type {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
              }
            }
          }
        }
        defaultValue
      }
    }
  }
`;
var SCHEMA_INTROSPECTION_QUERY = `
  query IntrospectionQuery {
    __schema {
      types {
        name
        kind
        description
        inputFields {
          name
          description
          type {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                }
              }
            }
          }
          defaultValue
        }
      }
    }
  }
`;
function parseTypeRef(type) {
  let required = false;
  let isList = false;
  let currentType = type;
  while (currentType) {
    if (currentType.kind === "NON_NULL") {
      required = true;
      currentType = currentType.ofType;
    } else if (currentType.kind === "LIST") {
      isList = true;
      currentType = currentType.ofType;
    } else {
      return {
        name: currentType.name || "Unknown",
        required,
        isList
      };
    }
  }
  return { name: "Unknown", required, isList };
}
function extractInputTypesFromQuery(query) {
  const inputTypes = /* @__PURE__ */ new Set();
  const varRegex = /\$\w+:\s*([A-Za-z_][A-Za-z0-9_]*(?:Input|Payload|Request|Data)?)/g;
  let match;
  while ((match = varRegex.exec(query)) !== null) {
    const typeName = match[1].replace(/[\[\]!]/g, "");
    if (typeName && !typeName.match(/^(String|Int|Float|Boolean|ID)$/)) {
      inputTypes.add(typeName);
    }
  }
  return Array.from(inputTypes);
}
function convertInputFieldsToSchema(inputFields) {
  const result = {};
  for (const field of inputFields) {
    const typeInfo = parseTypeRef(field.type);
    result[field.name] = {
      name: field.name,
      type: typeInfo.name,
      required: typeInfo.required,
      isList: typeInfo.isList,
      description: field.description || "",
      defaultValue: field.defaultValue
    };
  }
  return result;
}
var handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { apiKey, endpoint, query } = body;
    if (!apiKey) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "API key is required" })
      };
    }
    if (!query) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "GraphQL query is required" })
      };
    }
    const graphqlEndpoint = endpoint || "https://api.us.test.highnote.com/graphql";
    const inputTypes = extractInputTypesFromQuery(query);
    console.log("Found input types in query:", inputTypes);
    if (inputTypes.length === 0) {
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          success: true,
          inputs: {},
          message: "No input types found in query"
        })
      };
    }
    const trimmedApiKey = apiKey.trim();
    const encodedAuth = Buffer.from(`${trimmedApiKey}:`).toString("base64");
    const allInputs = {};
    const fetchedTypes = /* @__PURE__ */ new Set();
    const errors = [];
    for (const typeName of inputTypes) {
      try {
        console.log(`Fetching type details for: ${typeName}`);
        const response = await fetch(graphqlEndpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Basic ${encodedAuth}`,
            "Accept": "application/json"
          },
          body: JSON.stringify({
            query: TYPE_INTROSPECTION_QUERY,
            variables: { typeName }
          })
        });
        if (response.ok) {
          const result = await response.json();
          if (result.data?.__type?.inputFields) {
            allInputs[typeName] = convertInputFieldsToSchema(result.data.__type.inputFields);
            fetchedTypes.add(typeName);
            console.log(`Successfully fetched ${typeName}`);
          }
        }
      } catch (error) {
        console.error(`Failed to fetch type ${typeName}:`, error);
        errors.push(`Failed to fetch type ${typeName}`);
      }
    }
    if (fetchedTypes.size === 0) {
      console.log("Falling back to full schema introspection");
      const response = await fetch(graphqlEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Basic ${encodedAuth}`,
          "Accept": "application/json"
        },
        body: JSON.stringify({
          query: SCHEMA_INTROSPECTION_QUERY,
          variables: {}
        })
      });
      if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`Failed to fetch schema: ${response.statusText}`);
      }
      const result = await response.json();
      if (result.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(result.errors)}`);
      }
      const types = result.data.__schema.types;
      for (const typeName of inputTypes) {
        const type = types.find((t) => t.name === typeName && t.kind === "INPUT_OBJECT");
        if (type && type.inputFields) {
          allInputs[typeName] = convertInputFieldsToSchema(type.inputFields);
          fetchedTypes.add(typeName);
          console.log(`Found ${typeName} in schema`);
        } else {
          console.log(`Type ${typeName} not found in schema`);
          errors.push(`Type ${typeName} not found in schema`);
        }
      }
    }
    const processedTypes = new Set(fetchedTypes);
    const typesToProcess = Array.from(fetchedTypes);
    while (typesToProcess.length > 0) {
      const currentType = typesToProcess.shift();
      const fields = allInputs[currentType];
      if (fields) {
        for (const fieldName in fields) {
          const field = fields[fieldName];
          const fieldType = field.type;
          if (fieldType && !fieldType.match(/^(String|Int|Float|Boolean|ID|DateTime|Date|JSON)$/) && fieldType.endsWith("Input") && !processedTypes.has(fieldType)) {
            console.log(`Found nested type ${fieldType}, fetching...`);
            try {
              const response = await fetch(graphqlEndpoint, {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Authorization": `Basic ${encodedAuth}`,
                  "Accept": "application/json"
                },
                body: JSON.stringify({
                  query: TYPE_INTROSPECTION_QUERY,
                  variables: { typeName: fieldType }
                })
              });
              if (response.ok) {
                const result = await response.json();
                if (result.data?.__type?.inputFields) {
                  const nestedFields = convertInputFieldsToSchema(result.data.__type.inputFields);
                  field.fields = nestedFields;
                  allInputs[fieldType] = nestedFields;
                  processedTypes.add(fieldType);
                  typesToProcess.push(fieldType);
                }
              }
            } catch (error) {
              console.error(`Failed to fetch nested type ${fieldType}:`, error);
            }
          }
        }
      }
    }
    const enrichedInputs = {};
    for (const typeName of inputTypes) {
      if (allInputs[typeName]) {
        const enrichedFields = {};
        for (const fieldName in allInputs[typeName]) {
          const field = { ...allInputs[typeName][fieldName] };
          if (field.type && allInputs[field.type]) {
            field.fields = allInputs[field.type];
          }
          enrichedFields[fieldName] = field;
        }
        enrichedInputs.input = enrichedFields;
      }
    }
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        inputs: enrichedInputs,
        inputTypes: Array.from(fetchedTypes),
        errors: errors.length > 0 ? errors : void 0
      })
    };
  } catch (error) {
    console.error("Failed to enrich types:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        error: "Failed to enrich types",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
