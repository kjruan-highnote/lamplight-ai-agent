"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/introspect-schema.ts
var introspect_schema_exports = {};
__export(introspect_schema_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(introspect_schema_exports);
var INTROSPECTION_QUERY = `
  query IntrospectionQuery {
    __schema {
      queryType { name }
      mutationType { name }
      subscriptionType { name }
      types {
        ...FullType
      }
    }
  }

  fragment FullType on __Type {
    kind
    name
    description
    fields(includeDeprecated: true) {
      name
      description
      args {
        ...InputValue
      }
      type {
        ...TypeRef
      }
      isDeprecated
      deprecationReason
    }
    inputFields {
      ...InputValue
    }
    interfaces {
      ...TypeRef
    }
    enumValues(includeDeprecated: true) {
      name
      description
      isDeprecated
      deprecationReason
    }
    possibleTypes {
      ...TypeRef
    }
  }

  fragment InputValue on __InputValue {
    name
    description
    type { ...TypeRef }
    defaultValue
  }

  fragment TypeRef on __Type {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                }
              }
            }
          }
        }
      }
    }
  }
`;
function parseTypeRef(type) {
  let required = false;
  let isList = false;
  let currentType = type;
  while (currentType) {
    if (currentType.kind === "NON_NULL") {
      required = true;
      currentType = currentType.ofType;
    } else if (currentType.kind === "LIST") {
      isList = true;
      currentType = currentType.ofType;
    } else {
      return {
        name: currentType.name || "Unknown",
        required,
        isList
      };
    }
  }
  return { name: "Unknown", required, isList };
}
function extractOperationInputs(operationName, schema, operationType) {
  const typeName = operationType === "query" ? schema.__schema.queryType.name : operationType === "mutation" ? schema.__schema.mutationType.name : schema.__schema.subscriptionType?.name;
  if (!typeName) return null;
  const rootType = schema.__schema.types.find((t) => t.name === typeName);
  if (!rootType || !rootType.fields) return null;
  const operation = rootType.fields.find((f) => f.name === operationName);
  if (!operation || !operation.args) return null;
  const inputs = {};
  for (const arg of operation.args) {
    const typeInfo = parseTypeRef(arg.type);
    const inputType = schema.__schema.types.find((t) => t.name === typeInfo.name);
    inputs[arg.name] = {
      name: arg.name,
      type: typeInfo.name,
      required: typeInfo.required,
      isList: typeInfo.isList,
      description: arg.description || "",
      defaultValue: arg.defaultValue,
      fields: inputType?.inputFields ? extractInputFields(inputType, schema.__schema.types) : void 0
    };
  }
  return inputs;
}
function extractInputFields(type, allTypes) {
  if (!type.inputFields || type.inputFields.length === 0) return void 0;
  const fields = {};
  for (const field of type.inputFields) {
    const typeInfo = parseTypeRef(field.type);
    const fieldType = allTypes.find((t) => t.name === typeInfo.name);
    fields[field.name] = {
      name: field.name,
      type: typeInfo.name,
      required: typeInfo.required,
      isList: typeInfo.isList,
      description: field.description || "",
      defaultValue: field.defaultValue,
      // Recursively extract nested input fields (limit depth to prevent infinite recursion)
      fields: fieldType?.inputFields && !typeInfo.name.startsWith("__") ? extractInputFields(fieldType, allTypes) : void 0
    };
  }
  return fields;
}
var handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { apiKey, endpoint, operationName, operationType } = body;
    if (!apiKey) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "API key is required" })
      };
    }
    const graphqlEndpoint = endpoint || "https://api.us.test.highnote.com/graphql";
    const response = await fetch(graphqlEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
        "Accept": "application/json"
      },
      body: JSON.stringify({
        query: INTROSPECTION_QUERY,
        variables: {}
      })
    });
    if (!response.ok) {
      throw new Error(`Failed to fetch schema: ${response.statusText}`);
    }
    const result = await response.json();
    if (result.errors) {
      throw new Error(`GraphQL errors: ${JSON.stringify(result.errors)}`);
    }
    const schema = result.data;
    if (operationName && operationType) {
      const inputs = extractOperationInputs(operationName, schema, operationType);
      return {
        statusCode: 200,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          success: true,
          operation: operationName,
          type: operationType,
          inputs
        })
      };
    }
    const queryType = schema.__schema.types.find((t) => t.name === schema.__schema.queryType.name);
    const mutationType = schema.__schema.types.find((t) => t.name === schema.__schema.mutationType.name);
    const subscriptionType = schema.__schema.subscriptionType ? schema.__schema.types.find((t) => t.name === schema.__schema.subscriptionType.name) : null;
    const summary = {
      queries: queryType?.fields?.map((f) => ({
        name: f.name,
        description: f.description,
        deprecated: f.isDeprecated
      })) || [],
      mutations: mutationType?.fields?.map((f) => ({
        name: f.name,
        description: f.description,
        deprecated: f.isDeprecated
      })) || [],
      subscriptions: subscriptionType?.fields?.map((f) => ({
        name: f.name,
        description: f.description,
        deprecated: f.isDeprecated
      })) || []
    };
    const inputTypes = schema.__schema.types.filter((t) => t.kind === "INPUT_OBJECT").map((t) => ({
      name: t.name,
      description: t.description,
      fields: t.inputFields?.map((f) => ({
        name: f.name,
        type: parseTypeRef(f.type),
        description: f.description,
        defaultValue: f.defaultValue
      }))
    }));
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        summary,
        inputTypes,
        totalTypes: schema.__schema.types.length
      })
    };
  } catch (error) {
    console.error("Schema introspection failed:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        error: "Failed to introspect schema",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
