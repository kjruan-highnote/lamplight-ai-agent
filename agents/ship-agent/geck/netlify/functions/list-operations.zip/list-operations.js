"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/list-operations.ts
var list_operations_exports = {};
__export(list_operations_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(list_operations_exports);
var INTROSPECTION_QUERY = `
  query ListOperations {
    __schema {
      queryType { 
        name 
        fields {
          name
          description
        }
      }
      mutationType { 
        name 
        fields {
          name
          description
        }
      }
      subscriptionType { 
        name 
        fields {
          name
          description
        }
      }
    }
  }
`;
var handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS"
      },
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const body = JSON.parse(event.body || "{}");
    const { apiKey, endpoint } = body;
    if (!apiKey) {
      return {
        statusCode: 400,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: "API key is required" })
      };
    }
    const graphqlEndpoint = endpoint || "https://api.us.test.highnote.com/graphql";
    const trimmedApiKey = apiKey.trim();
    const encodedAuth = Buffer.from(`${trimmedApiKey}:`).toString("base64");
    console.log("Fetching available operations from:", graphqlEndpoint);
    const response = await fetch(graphqlEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Basic ${encodedAuth}`,
        "Accept": "application/json"
      },
      body: JSON.stringify({
        query: INTROSPECTION_QUERY,
        variables: {}
      })
    });
    if (!response.ok) {
      const errorBody = await response.text();
      console.error("API Response Status:", response.status);
      console.error("API Response:", errorBody);
      throw new Error(`Failed to fetch schema: ${response.statusText} (${response.status})`);
    }
    const result = await response.json();
    if (result.errors) {
      throw new Error(`GraphQL errors: ${JSON.stringify(result.errors)}`);
    }
    const schema = result.data.__schema;
    const operations = {
      queries: schema.queryType?.fields?.map((f) => ({
        name: f.name,
        description: f.description
      })) || [],
      mutations: schema.mutationType?.fields?.map((f) => ({
        name: f.name,
        description: f.description
      })) || [],
      subscriptions: schema.subscriptionType?.fields?.map((f) => ({
        name: f.name,
        description: f.description
      })) || []
    };
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        success: true,
        operations,
        stats: {
          queries: operations.queries.length,
          mutations: operations.mutations.length,
          subscriptions: operations.subscriptions.length,
          total: operations.queries.length + operations.mutations.length + operations.subscriptions.length
        }
      })
    };
  } catch (error) {
    console.error("Failed to list operations:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({
        error: "Failed to list operations",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
