"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_middleware.ts
var middleware_exports = {};
__export(middleware_exports, {
  withErrorLogging: () => withErrorLogging
});
module.exports = __toCommonJS(middleware_exports);
var withErrorLogging = (handler) => {
  return async (event, context) => {
    const startTime = Date.now();
    const functionName = context.functionName || "unknown";
    console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] ${functionName} - ${event.httpMethod} ${event.path}`);
    if (event.queryStringParameters) {
      console.log(`Query params:`, event.queryStringParameters);
    }
    try {
      const response = await handler(event, context);
      const duration = Date.now() - startTime;
      console.log(`[${(/* @__PURE__ */ new Date()).toISOString()}] ${functionName} - Status: ${response.statusCode} - Duration: ${duration}ms`);
      return response;
    } catch (error) {
      const duration = Date.now() - startTime;
      console.error(`[${(/* @__PURE__ */ new Date()).toISOString()}] ${functionName} - ERROR after ${duration}ms:`, {
        message: error.message,
        stack: error.stack,
        event: {
          httpMethod: event.httpMethod,
          path: event.path,
          headers: event.headers,
          queryStringParameters: event.queryStringParameters,
          body: event.body ? event.body.substring(0, 1e3) : null
          // Log first 1000 chars of body
        }
      });
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS"
        },
        body: JSON.stringify({
          error: "Internal Server Error",
          message: error.message,
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        })
      };
    }
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  withErrorLogging
});
